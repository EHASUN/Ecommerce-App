/*
 *
 * Application constants
 *
 */

export const DEFAULT_ACTION = 'src/Application/DEFAULT_ACTION';
